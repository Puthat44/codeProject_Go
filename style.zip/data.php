<?php
// การตั้งค่าการเชื่อมต่อฐานข้อมูล
$servername = "localhost";
$username = "root"; // ชื่อผู้ใช้ฐานข้อมูล
$password = ""; // รหัสผ่านของผู้ใช้
$dbname = "SensorDB";

// สร้างการเชื่อมต่อ
$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ตรวจสอบว่ามีข้อมูลส่งมาหรือไม่
if (isset($_GET['object_count'])) {
    $object_count = intval($_GET['object_count']); // รับค่าจาก Arduino

    // เพิ่มข้อมูลลงในฐานข้อมูล
    $sql = "INSERT INTO SensorData (sensor_state) VALUES ($object_count)";
    if ($conn->query($sql) === TRUE) {
        echo "Data saved successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "No data received";
}

// ปิดการเชื่อมต่อ
$conn->close();
?>
