<!DOCTYPE html>
<html>
<head>
    <title>ตู้แลกดินสอด้วยขวดพลาสติก / กระป๋อง </title>
    <link rel="shortcut icon" href="/pencil-case.png" type="image/x-icon">
   <!--  <meta http-equiv="refresh" content="10">  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://bit.ly/3CZa0Sz" type="text/css" charset="utf-8" />
    <link rel="stylesheet" href="style.css">
    <style type="text/css">
    body {
        font-family: 'line_seed_sans_th';
        margin: 0;
        padding: 0;
    }
    </style>
</head>
<body>



<div class="container d-flex justify-content-center" style="margin-top: 15rem">
    <button class="btn btn-dezen" onclick="refreshPage()">รีเฟรชหน้าจอ <i class="bi bi-arrow-clockwise"></i></button>
</div>


<div class="container mt-5">
    <div class="row">
        <h1 class="text-center mb-3 mt-3">ตู้แลกดินสอด้วยขวดพลาสติก / กระป๋อง 
            <P style="font-size: 14px; color:#bababa;">เมื่อกระป๋องครบ 30 จะทำการีเซทค่าใหม่ทันที</P>
        </h1>
        <div id="latestData">
            <!-- ข้อมูลล่าสุดจะแสดงที่นี่ -->
        </div>
    </div>
</div>



<div class="footer text-center " style="margin-top: 10rem">
    <div class="row">
        <div class="col">
            <p style="font-size:12px; color:#91929e;">DEV. Puthat - BZKL, By Bakiduzz</p>
        </div>
    </div>
</div>




    <script>
        function refreshPage() {
            location.reload(); // คำสั่งรีเฟรชหน้าเว็บ
        }
    </script>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
// ฟังก์ชันเพื่อดึงข้อมูลล่าสุดแบบเรียลไทม์
function loadLatestData() {
    $.ajax({
        url: 'backend.php', // เปลี่ยนเป็นที่อยู่ PHP ของคุณ
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            // ตรวจสอบว่ามีข้อมูลหรือไม่
            if (response.latestData) {
                $('#latestData').html(response.latestData); // อัพเดตข้อมูลล่าสุดบนหน้าเว็บ
            } else {
                $('#latestData').html('<p class="text-center">ไม่มีข้อมูลล่าสุด</p>'); // ถ้าไม่มีข้อมูล ให้แสดงข้อความว่าไม่มีข้อมูล
            }
        }
    });
}

// ตั้งเวลาให้ดึงข้อมูลใหม่ทุกๆ 1 วินาที (1000 มิลลิวินาที)
setInterval(loadLatestData, 1);


// การส่งข้อมูลผ่านฟอร์ม
$('#dataForm').on('submit', function(event) {
    event.preventDefault(); // ป้องกันการรีเฟรชหน้า

    var objectCount = $('#test_sensor_state').val();

    $.ajax({
        url: 'backend.php', // เปลี่ยนเป็น PHP สำหรับการเพิ่มข้อมูล
        method: 'POST',
        data: {
            test_sensor_state: objectCount
        },
        success: function(response) {
            // ดึงข้อมูลล่าสุดหลังจากเพิ่มข้อมูลแล้ว
            loadLatestData();
        }
    });
});
</script>


</body>
</html>
