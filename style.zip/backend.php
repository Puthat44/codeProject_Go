<?php
// ตั้งค่าการเชื่อมต่อฐานข้อมูล
$servername = "localhost";
$username = "root";
$password = "";
$database = "SensorDB";  // ชื่อฐานข้อมูล

// สร้างการเชื่อมต่อ
$conn = new mysqli($servername, $username, $password, $database);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ดึงข้อมูลล่าสุดจากฐานข้อมูล
$sqlLatest = "SELECT * FROM sensordata ORDER BY timestamp DESC LIMIT 1";
$resultLatest = $conn->query($sqlLatest);
$latestData = "";

if ($resultLatest->num_rows > 0) {
    $row = $resultLatest->fetch_assoc();
    $latestData = "
    <div class='d-flex justify-content-center gap-2'>
        <div class='card-dezen text-center pt-2 col-lg-1'>
            <h3>ID</h3>
            <p>{$row['id']}</p>
        </div>
        <div class='card-dezen text-center pt-2 col-lg-3'>
            <h3>จำนวนขวดน้ำ - กระป๋อง</h3>
            <p class='card-xx'>{$row['sensor_state']}</p>
        </div>
        <div class='card-dezen text-center pt-2 col-lg-3'>
            <h3>วันที่และเวลา</h3>
            <p>{$row['timestamp']}</p>
        </div>
    </div>" ;

    // ดึงวันที่และเวลา
    $timestamp = $row['timestamp'];

    // ตรวจสอบจำนวนวัตถุ
    if ($row['sensor_state'] >= 30 && $row['alert_sent'] == 0) {
        // ส่งการแจ้งเตือนทาง LINE Notify โดยเพิ่มเวลาในข้อความ
        $lineResponse = sendLineNotify("จำนวนขวด&กระป๋องครบ 30 ขวดแล้ว! เวลา: $timestamp น.");
        
        // ตรวจสอบผลลัพธ์การส่ง LINE Notify
        if (!$lineResponse) {
            echo "<p>Error sending LINE Notify.</p>";
        }

        // รีเซ็ตสถานะการแจ้งเตือนในฐานข้อมูล
        $updateAlertStatus = "UPDATE sensordata SET alert_sent = 1 WHERE id = {$row['id']}";
        $conn->query($updateAlertStatus);
    }
} else {
    $latestData = "<p class='text-center'>ไม่มีข้อมูลล่าสุด</p>";
}

$conn->close();

// ส่งข้อมูลในรูปแบบ JSON
echo json_encode(['latestData' => $latestData]);

// ฟังก์ชันส่งข้อความผ่าน LINE Notify
function sendLineNotify($message) {
    $lineToken = "cm3fFLOllm2gXGxZmqbZ4uazhGpfm0fkqkb9ImH0xZe"; // แทนที่ด้วย Access Token ของคุณ
    $url = "https://notify-api.line.me/api/notify";

    $data = http_build_query(['message' => $message]);
    $headers = [
        "Content-Type: application/x-www-form-urlencoded",
        "Authorization: Bearer $lineToken"
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}
?>
